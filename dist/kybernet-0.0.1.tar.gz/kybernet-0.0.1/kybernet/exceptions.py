

class ObjectNotFound(Exception):
    pass
clas InvalidOperation(Exception):
    pass