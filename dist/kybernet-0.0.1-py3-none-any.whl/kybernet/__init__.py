""" 
Ego scribo Python ergo ego exaltatus fueris.
 
et invisio: https://vertele.eldiario.es/2017/09/04/noticias/Nikolaj-Coster-Waldau-Shot-Caller_1936616392_8723486_1819x1024.jpg
"""
